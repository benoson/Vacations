self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "3a7fc3ce056c425eac3400fdeca47541",
    "url": "/index.html"
  },
  {
    "revision": "283295752655b36ee941",
    "url": "/static/css/main.b7350355.chunk.css"
  },
  {
    "revision": "4ec1aacf40b4e6604aa4",
    "url": "/static/js/2.84ed13df.chunk.js"
  },
  {
    "revision": "172a113972f1e5cfab578d1e7c545daa",
    "url": "/static/js/2.84ed13df.chunk.js.LICENSE.txt"
  },
  {
    "revision": "283295752655b36ee941",
    "url": "/static/js/main.6940a4b9.chunk.js"
  },
  {
    "revision": "4d35b5b39293d9bb0421",
    "url": "/static/js/runtime-main.63a5cbd0.js"
  },
  {
    "revision": "2b2169c009067919438cb64528eac695",
    "url": "/static/media/addSign.2b2169c0.svg"
  },
  {
    "revision": "a83ce8a95874d8dda6854a9c8d112366",
    "url": "/static/media/astronautSVG.a83ce8a9.svg"
  },
  {
    "revision": "df0602a9a16630312e3f8be22d88876b",
    "url": "/static/media/bannerBackground4.df0602a9.png"
  },
  {
    "revision": "7f35f1222fc0d69074739edf7a1070ed",
    "url": "/static/media/deleteModalBGSVG.7f35f122.svg"
  },
  {
    "revision": "4eb942cd7c2a1b5d85fb16a063f27e22",
    "url": "/static/media/deleteSVG.4eb942cd.svg"
  },
  {
    "revision": "312ca80c5f72acd5f25f50c3c62e93c6",
    "url": "/static/media/emptyImgBG.312ca80c.png"
  },
  {
    "revision": "45598562077bdc84281b5330ff4d283e",
    "url": "/static/media/heartAnimationImage.45598562.png"
  },
  {
    "revision": "ae39de0153db373c9b0671c6ec251401",
    "url": "/static/media/noAuthorizationSVG.ae39de01.svg"
  },
  {
    "revision": "4766456e88d67d362304ee569a55c72b",
    "url": "/static/media/settingsImg.4766456e.png"
  },
  {
    "revision": "7f4d39c23416e33bf9a59d7be90aeb95",
    "url": "/static/media/spinningEarthSVG.7f4d39c2.svg"
  },
  {
    "revision": "c4512a2e16726ff18af271deae96034e",
    "url": "/static/media/wavy.c4512a2e.png"
  },
  {
    "revision": "c757db26fce5e339c726731c7b6bf664",
    "url": "/static/media/wavyCorner.c757db26.png"
  },
  {
    "revision": "60376494daed797719cad804eb777bc1",
    "url": "/static/media/wavyCyan.60376494.png"
  }
]);