// ---------- Defining The User's Cache Inside The Server ---------- //

const userServerCache = new Map();

module.exports = userServerCache;