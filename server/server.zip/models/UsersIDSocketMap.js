// -------- Defining a Map That Represents And Holds The Users That Are Connected With Sockets To The Server -------- //

const usersIDSocketMap = new Map();

module.exports = usersIDSocketMap;